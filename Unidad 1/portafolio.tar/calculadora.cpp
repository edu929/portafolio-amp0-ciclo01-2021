#include "calculadora.h"

#include <iostream>

int main()
{
	cout << valorPi() << '\n';
	calculadora();
	return 0;
}




