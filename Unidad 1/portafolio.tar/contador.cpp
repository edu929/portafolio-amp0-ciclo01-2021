#include <iostream>
using namespace std;
int main(){
int contador = 1;
	while (contador < 10) {
		cout << contador << ": Hola" <<  endl;
		contador++;
	}
	{
		return 0;
	}
	
		
		
	}
