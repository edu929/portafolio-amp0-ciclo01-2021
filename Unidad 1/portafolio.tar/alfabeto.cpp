#include <iostream>
using namespace std;

	void imprimirAlfabeto() {
		char letra = 'A';
		
		while (letra <= 'Z'){
			cout << letra << " ";
			letra++;

	}
	cout << endl;
	
}

int main(){
	imprimirAlfabeto();
}
